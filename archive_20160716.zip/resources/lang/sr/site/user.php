<?php

return [
	'login' => 'Пријава',
	'login_to_account' => 'Пријавите се на ваш налог',
	'submit' => 'Пошаљи',
	'register' => 'Креирање новог налога',
	'remember' => 'Запамти',
	'password' => 'Лозинка',
	'e_mail' => 'E-маил',
	'register' => 'Регистрација',
	'password_confirmation' => 'Поновљена лозинка',
	'confirmation_required' => 'Потврда налога је обавезна',
	'name' => 'Име',
	'home' => 'Почетна',
	'email_required' => 'Морате унијети исправну емаил адресу',
	'email_unique' => 'Постоји корисник који се већ регистровао са том емаил адресом',
	'name_required' => 'Морате унијети Ваше име',
	'password_required' => 'Морате унијети вашу лозинку',
	'password_confirmed' => 'Морате унијети поновљену лозинку',
	'change_password' => 'Промјена лозинке',
	
	];
