<?php

return [
    'videoalbum' => 'Видео албуми',
    'numbers_of_items' =>'Број ставки',
    'description' => 'Опис',


];