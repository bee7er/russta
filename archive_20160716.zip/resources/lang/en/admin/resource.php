<?php

return [
    'resource' => 'Resources',
    'type' =>  'Type',
    'name' => 'Name',
    'description' => 'Description',
    'template' => 'Template',
    'image' => 'Image',
    'thumb' => 'Thumb',
    'url' => 'Url',

];