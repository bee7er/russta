<?php

return [
    'template' => 'Templates',
    'name' => 'Name',
    'container' => 'Container'
];