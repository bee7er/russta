<?php

return [
    'videoalbum' => 'Video albumi',
    'numbers_of_items' =>'Broj stavki',
    'description' => 'Opis',


];