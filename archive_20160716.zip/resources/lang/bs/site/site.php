<?php

return [
	'home' => 'Početna',
	'login' => 'Prijava',	
	'sign_up' => 'Registracija',
	'admin_panel' => 'Admin Dio',
	'logout' => 'Odjava',
	'login_as' => 'Prijavljeni ste kao',
	
];
