@extends('layouts.app')
@section('title') Contact :: @parent @endsection
@section('content')

    @include('partials.header')

    <div class="row">
        <div class="page-header">
            <h2>Contact Page</h2>
        </div>
    </div>
@endsection