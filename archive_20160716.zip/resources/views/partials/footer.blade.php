<!-- Footer sticks to the bottom of the page -->
<div class="bottom-footer">
    <span style="float: left;color: #fff;margin:10px 0 0 10px;">&copy; russell etheridge 2016</span>
</div>